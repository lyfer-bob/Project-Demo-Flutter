import 'package:get/get.dart';

class DemoController extends GetxController {
  init() {}
}
