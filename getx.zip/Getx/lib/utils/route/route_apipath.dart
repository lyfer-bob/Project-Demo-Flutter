class ApiPath {
  ApiPath();
  static const String apiPath = 'http://xxxxxxx.com/';
  static const String login = '$apiPath/Login';
  static const String logout = '$apiPath/Logout';
}
