

class MenuRepository {
  int getDatatest(int num1, int num2) => num1 + num2;
}
