package com.getx.project

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
